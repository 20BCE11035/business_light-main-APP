//////////////! * Id Pagination Class * ///////////////
abstract class PaginationId {
  int lastId = 0;
}
