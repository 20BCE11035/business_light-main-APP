/// Using all links and urls inside this class (Privacy Policy, Terms of usage, and more)
class ConstUrls {
  static String get examplePrivacyPolicy =>
      'https://www.shopaccino.com/privacy-policy.html';
}
