import 'package:fluent_ui/fluent_ui.dart';

Widget defaultTopPadding({double value = 60}) =>
    Padding(padding: EdgeInsets.only(top: value));
