import 'package:fluent_ui/fluent_ui.dart';

class SettingsColor {
  SettingsColor({required this.color, required this.name});
  Color color;
  String name;
}
